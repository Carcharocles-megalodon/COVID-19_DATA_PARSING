﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace downloader
{
    class Country
    {
        public uint Confirmed { get; set; }
        public uint Deaths { get; set; }
        public uint Recovered { get; set; }
    }
}
