# COVID-19_DATA_PARSING
Uni pair project for parsing information relevant to COVID-19 and outputting to a readable format;
